﻿namespace Farm
{
    using System;
    public class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking…");
        }
    }
}